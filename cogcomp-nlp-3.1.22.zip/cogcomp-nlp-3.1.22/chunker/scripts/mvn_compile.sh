#!/bin/bash

# My OCD tells me to keep this...
mvn compile
