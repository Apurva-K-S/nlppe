Big-Data Utils
==============
This is a utility package containing easy to use interfaces for several libraries like MapDB, Lucene, H2 database etc.

Maven Coordinates
-----------------
```xml
  <groupId>edu.illinois.cs.cogcomp</groupId>
  <artifactId>big-data-utils</artifactId>
  <version>1.0.1</version> 
```

Usage
=====

Using MapDB
-----
Simple use case - a disk based map for your too-large-to-fit-in-memory hashMap needs.

```java 
	// creates a hashmap named "freebase_cache" stored on disk under "data/freebaseRawResponseCache/" and returns it. 
	// if a disk based map named "freebase_cache" was already stored there, then simply reopens that map.
	// so basically just use this.
	Map<String, String> map = MapDB.newDefaultDb("data/freebaseRawResponseCache/",
	"freebase_cache").make().getHashMap("freebase_cache");
	System.out.println(map.size());
	for (String key : map.keySet()) {
	    // System.out.println(map.get(key));
	   fb.lookup(key);
	}
```
This will be nearly as fast as a memory based map in terms of access, but just not stored in memory.

For read-only writing to mapDB map use,
```java
	DBMaker dbmaker=MapDB.newDefaultDb(wikititle2freebaseMidcacheLocation,"freebase_cache")
	DB db=MapDB.DBConfig.READ_ONLY.configure(dbmaker).make();
	Map<String, String> readonlyMap=db.getHashMap("freebase_cache");
```

Faster insertion into map using pump,

```java
	Map newMap = db.createTreeMap("map")
	    .pumpSource(randomIterator)  //source of data to import
            .pumpBatchSize(1000000)      //sort data from source, batch size must be set so it fits into memory
	    .make()
```
It has linear speed with number of records. It will sort data even if they do not fit into memory. Read [this](http://stackoverflow.com/questions/25538711/how-to-sort-items-for-faster-insertion-in-the-mapdb-btree)


Using H2 Database helper
-----
Look at  `DBExample`  in test package `edu.illinois.cs.cogcomp.bigdata.database`.
This shows how to create a db for you at the location specified by dbFile
Once you are done populating, you can view the db by connecting to it by running

```bash
java -cp target/dependency/h2-1.4.182.jar org.h2.tools.Server -web -webPort 9090
```

and connecting to the dbURL. The default username is blank, dbURL
should have absolute system path
(eg. `"jdbc:h2:/Users/Shyam/java_code/wikiutils/database"`).


Using Lucene
-----
You can easily call commonly used Lucene classes from the static utility library Lucene. It also houses functions for getting term freqs and the like.

```java
	public class LuceneExample {

	public static void main(String[] args) throws IOException, ParseException {

		String pathToIndexDir = "testIndex";
		createIndex(pathToIndexDir);
		IndexReader reader = Lucene.reader(pathToIndexDir);
		Map<String, Float> idfs = Lucene.getIdfs(reader, "text");
		for (String k : idfs.keySet()) {
			System.out.println(k + " " + idfs.get(k));
		}
		System.out.println("TFS");
		for (int i = 0; i < reader.maxDoc(); i++) {
			System.out.println(reader.document(i).getField("title")
					.stringValue());
			Map<String, Float> tfs = Lucene.getTfs(reader, "text", i);
			for (String k : tfs.keySet()) {
				System.out.println(k + " " + tfs.get(k));
			}
		}

	}

	private static void createIndex(String pathToIndexDir) throws IOException {
		IndexWriter w = Lucene.writer(pathToIndexDir,
				Lucene.newConfig(Lucene.SIMPLE));
		addDoc(w, "Lucene in Action", "193398817",
				"This is a book on lucene and this book is awesome");
		addDoc(w, "Lucene for Dummies", "55320055Z",
				"Book for dummies. I read it to this day");
		addDoc(w, "Managing Gigabytes", "55063554A",
				"Book on managing gigabytes. Not very interesting");
		addDoc(w, "The Art of Computer Science", "9900333X",
				"Was this book written by Knuth?");
		addDoc(w, "Concrete Mathematics", "9900333X",
				"Cute book on combinatorics and other discrete maths. By Knuth and Graham");
		addDoc(w, "The Art of Zen", "9900333X", "Some book on Zen Buddhism");
		addDoc(w,
				"Hamlet",
				"12313123",
				"to be or not to be. Do be do be do.");
		addDoc(w, "Zen and Some Motorcycle Nonsense", "9900333X",
				"American take on Zen Buddhism. They mostly talk about motorcycles though");

		w.close();
	}

	private static void addDoc(IndexWriter w, String title, String isbn,
			String text) throws IOException {
		Document doc = new Document();
		doc.add(new TextField("title", title, Field.Store.YES));
		doc.add(new StringField("isbn", isbn, Field.Store.YES));
		doc.add(new Field("text", text, Lucene.FULL_INDEX));
		// need above otherwise cannot call tf idf functions. This stores tf idf vectors
		w.addDocument(doc);
	}
```

## Citation

If you use this code in your research, please provide the URL for this github repository in the relevant publications.
Thank you for citing us if you use us in your work!
